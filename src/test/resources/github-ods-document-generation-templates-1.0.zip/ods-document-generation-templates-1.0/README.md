# ods-document-generation-templates
ODS lifecycle documentation generation - document templates
